
<html lang="en" translate="no" data-dpr="1" style="font-size: 37.5px;"><head>
		<meta charset="UTF-8">
		<link rel="icon" type="image/svg+xml" href="">
		<meta name="google" content="notranslate">
		<meta name="robots" content="noindex,nofollow">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no,viewport-fit=cover">
		<link rel="stylesheet" href="/indexh.css">
		<!--动态选择配置文件-->
		<link rel="manifest">
		<title>Global Bet-24</title>
		<script type="module" crossorigin="" src="/assets/js/index-fbf0707b.js"></script>
		<link rel="modulepreload" crossorigin="" href="/assets/js/vendor-b2024301.js">
		<link rel="stylesheet" href="/assets/css/index-3cf8aaa6.css">
	<script> window._TENANT = []; </script>
<script> window._CONFIG = {
  "tenant": "daman",
  "scenes": "ScenesDaman"
}; </script>
<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/index-74b8a99f.js">
	<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/LangPopup-08a11cc6.js">
	<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/index-4a5675bf.js">
	<link rel="stylesheet" href="/assets/css/index-f18748b8.css">
	<link rel="stylesheet" href="/assets/css/LangPopup-51cc2937.css">
	<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/SlideCaptcha-7b0791d7.js">
	<link rel="stylesheet" href="/assets/css/SlideCaptcha-2937b4a9.css">
	<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/PasswordInput-31e16272.js">
	<link rel="stylesheet" href="/assets/css/PasswordInput-39e32c58.css">
	<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/PhoneInput-cdb15012.js">
	<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/DropDown-f1f7db31.js">
	<link rel="stylesheet" href="/assets/css/DropDown-f83d38a9.css">
	<link rel="stylesheet" href="/assets/css/PhoneInput-d06cfae1.css">
	<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/VerifyInput-776957e7.js">
	<link rel="stylesheet" href="/assets/css/VerifyInput-ba9a4f32.css">
	<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/validate-0bf9ac20.js">
	<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/useCode.hook-56068ce8.js">
	<link rel="modulepreload" as="script" crossorigin="" href="/assets/js/EmailInput-42416bc1.js">
	<link rel="stylesheet" href="/assets/css/EmailInput-2bd6f8af.css">
	<link rel="stylesheet" href="/assets/css/index-d5587658.css">
	</head>
	<body style="font-size: 12px;">	
		<div id="app" data-v-app="">
			<div data-v-61e74e3f="" class="ar-loading-view" style="display: none; --f817f0ee: 'Roboto', 'Inter', sans-serif;">
				<div data-v-61e74e3f="" class="loading-wrapper">
					<div data-v-61e74e3f="" class="loading-animat">
						</div>
					
					<div data-v-61e74e3f="" class="com__box" style="display: none;">
						<div class="loading" data-v-61e74e3f="">
							<div class="shape shape-1" data-v-61e74e3f=""></div>
							<div class="shape shape-2" data-v-61e74e3f=""></div>
							<div class="shape shape-3" data-v-61e74e3f=""></div>
							<div class="shape shape-4" data-v-61e74e3f=""></div>
						</div>
					</div>
				</div>
				<div data-v-61e74e3f="" class="skeleton-wrapper" style="display: none;">
					<div data-v-61e74e3f="" class="van-skeleton van-skeleton--animate">
						<div class="van-skeleton__content">
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 60%;"></div>
						</div>
					</div>
					<div data-v-61e74e3f="" class="van-skeleton van-skeleton--animate">
						<div class="van-skeleton-avatar van-skeleton-avatar--round"></div>
						<div class="van-skeleton__content"><h3 class="van-skeleton-title">
							</h3>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 60%;"></div>
						</div>
					</div>
					<div data-v-61e74e3f="" class="van-skeleton van-skeleton--animate">
						<div class="van-skeleton__content">
							<h3 class="van-skeleton-title"></h3>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 100%;"></div>
							<div class="van-skeleton-paragraph" style="width: 60%;"></div>
						</div>
					</div>
				</div>
			</div>
			<div data-v-a4c8bf60="" class="resgister__C" style="--f817f0ee: 'Roboto', 'Inter', sans-serif;">
				<div data-v-81ead1cb="" data-v-a4c8bf60="" class="navbar">
					<div data-v-81ead1cb="" class="navbar-fixed wc" style="background: rgb(43, 50, 112);">
						<div data-v-81ead1cb="" class="navbar__content">
							<div data-v-81ead1cb="" class="navbar__content-left">
								<i data-v-81ead1cb="" class="van-badge__wrapper van-icon van-icon-arrow-left"></i></div>
							<div data-v-81ead1cb="" class="navbar__content-center">
								<!--<img src="https://root.winzy.app/assets/win4cash_logo.png" height="400%">-->
								<h1 style="color:white;">Global Bet 24</h1>
								</div>
								<div data-v-81ead1cb="" class="navbar__content-title"></div>
							</div>
							<div data-v-81ead1cb="" class="navbar__content-right">
								<div data-v-4eb25d27="" data-v-a4c8bf60=""><!---->
		<form action="{{route('user_register',$ref_id->referral_code)}}" method="post">
		    @csrf
		</div>
		</div></div></div></div>		
					<div style="text-align:center;margin-top: 1rem;">
						<img data-v-dba00bcf="" src="/assets/png/cellphone-35529171.png" class="phoneInput__container-label__icon">
							<p style="color : #759fde; font-weight: bold; font-size: 20px;">Register your phone</p>
						<hr>
					</div>
					
					<div data-v-a4c8bf60="" class="resgister__C-form">
						<div data-v-a4c8bf60="" class="tab-content activecontent">
							<div data-v-327ab6b4="" data-v-a4c8bf60="" class="register__container">
								<div data-v-dba00bcf="" data-v-327ab6b4="" class="phoneInput__container">
									<div data-v-dba00bcf="" class="phoneInput__container-label">
										<img data-v-dba00bcf="" src="/assets/png/cellphone-35529171.png" class="phoneInput__container-label__icon">
										<span data-v-dba00bcf="">Phone number</span>
									</div>
									<div data-v-dba00bcf="" class="phoneInput__container-input">
										<div data-v-183fb3f9="" data-v-dba00bcf="" class="dropdown">
											<div data-v-183fb3f9="" class="dropdown__value">
												<span data-v-183fb3f9="">+91</span>
												<i data-v-183fb3f9="" class="van-badge__wrapper van-icon van-icon-arrow-down">
													</i>
											</div>
											<div data-v-183fb3f9="" class="dropdown__list">
												<div data-v-183fb3f9="" class="dropdown__list-item active">
													<span data-v-183fb3f9="">+91</span> India (भारत)
												</div>
											</div>
										</div>
										<input data-v-dba00bcf="" type="number" name="mobile" placeholder="Please enter the phone number" maxlength="10" required>
		
		</div>
		 @error('mobile')
            <div class="alert alert-warning" style="color: white;">{{ $message }}</div>
        @enderror
		</div>
				<div data-v-327ab6b4="" class="register__container-tips" style="display: none;"><span data-v-327ab6b4="">Entered twice the password does not match!</span></div><div data-v-327ab6b4="" class="register__container-invitation"><div data-v-327ab6b4="" class="register__container-invitation__label"><img data-v-327ab6b4="" class="register__container-invitation__label-icon" data-src="/assets/png/invitation-5285cf0f.png" src="/assets/png/invitation-5285cf0f.png" lazy="loaded"><span data-v-327ab6b4="">Email</span></div><div data-v-327ab6b4="" class="register__container-invitation__input"><input data-v-327ab6b4="" name="email"  required value="" type="text"  placeholder="Please enter your email"  maxlength="40">    
		</div>
		@error('email')
            <div class="alert alert-warning" style="color: white;">{{ $message }}</div>
        @enderror
		</div><br><br><br>
		
		<div data-v-327ab6b4="" class="tip"><!----><!----></div><!----><div data-v-934f92c4="" data-v-327ab6b4="" class="passwordInput__container"><div data-v-934f92c4="" class="passwordInput__container-label"><img data-v-934f92c4="" class="passwordInput__container-label__icon" data-src="/assets/png/password-12e0a3fc.png" src="/assets/png/password-12e0a3fc.png" lazy="loaded"><span data-v-934f92c4="">Set password</span></div><div data-v-934f92c4="" class="passwordInput__container-input"><input data-v-934f92c4="" type="password" required placeholder="Set password" name="password" maxlength="15" autocomplete="new-password">
		
		<img data-v-934f92c4="" src="/assets/png/eyeInvisible-821d9d16.png" class="eye"></div>
		 @error('password')
            <div class="alert alert-warning"style="color: white;">{{ $message }}</div>
        @enderror
        </div><div data-v-327ab6b4="" class="register__container-tip" style="display: none;"><div data-v-327ab6b4="" class="tipbg"></div><span data-v-327ab6b4="">The password must be at least 8 digits and must contain letters + numbers</span></div><div data-v-934f92c4="" data-v-327ab6b4="" class="passwordInput__container"><div data-v-934f92c4="" class="passwordInput__container-label"><img data-v-934f92c4="" class="passwordInput__container-label__icon" data-src="/assets/png/password-12e0a3fc.png" src="/assets/png/password-12e0a3fc.png" lazy="loaded"><span data-v-934f92c4="">Confirm password</span></div><div data-v-934f92c4="" class="passwordInput__container-input"><input data-v-934f92c4="" type="password" required name="password" placeholder="Confirm password" maxlength="15" autocomplete="new-password">
		         
		<img data-v-934f92c4="" src="/assets/png/eyeInvisible-821d9d16.png" class="eye"></div>
		 @error('password')  
            <div class="alert alert-warning" style="color: white;">{{ $message }}</div>
        @enderror
		</div><div data-v-327ab6b4="" class="register__container-tips" style="display: none;"><span data-v-327ab6b4="">Entered twice the password does not match!</span></div><div data-v-327ab6b4="" class="register__container-invitation"><div data-v-327ab6b4="" class="register__container-invitation__label"><img data-v-327ab6b4="" class="register__container-invitation__label-icon" data-src="/assets/png/invitation-5285cf0f.png" src="/assets/png/invitation-5285cf0f.png" lazy="loaded"><span data-v-327ab6b4="">Invite code</span></div><div data-v-327ab6b4="" class="register__container-invitation__input"><input data-v-327ab6b4="" name="referral_code" value="{{$ref_id->referral_code}}" type="text" auto-complete="new-password" autocomplete="off" name="userNumber" placeholder="Please enter your email" disabled="" maxlength="40">
		</div></div>

		<div data-v-327ab6b4="" class="register__container-remember"><div data-v-327ab6b4="" role="checkbox" class="van-checkbox" tabindex="0" aria-checked="false"><div class="van-checkbox__icon van-checkbox__icon--round"><i class="van-badge__wrapper van-icon van-icon-success"></i></div><span class="van-checkbox__label">I have read and agree <span data-v-327ab6b4="">【Privacy Agreement】</span></span></div></div><div data-v-327ab6b4="" class="register__container-button">
		<button data-v-327ab6b4="" type="submit">Register</button>
		

		
		</div></div></div><!----></div></div><div class="customer" id="customerId" style="--f817f0ee: 'Roboto', 'Inter', sans-serif; --733cb41a: bahnschrift;"><img data-src="/assets/png/icon_sevice-f79b6ecd.png" src="/assets/png/icon_sevice-f79b6ecd.png" lazy="loaded"></div>
		</form>
			
		</div>
		
	

<!----><!----><!----><!----></body></html>
